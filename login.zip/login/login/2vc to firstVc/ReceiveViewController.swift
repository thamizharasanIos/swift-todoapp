//
//  ReceiveViewController.swift
//  login
//
//  Created by thamizharasan t on 28/03/22.
//

import UIKit

class ReceiveViewController: UIViewController {
  

    @IBOutlet weak var labelss: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func next(_ sender: Any) {
        let SenderVc = storyboard?.instantiateViewController(withIdentifier: "nexttt") as! SenderViewController
        SenderVc.selectionDelegate = self
        present(SenderVc, animated: true, completion: nil)
    }
    
}
 
extension ReceiveViewController: selectDelgate{
    func text(t: String) {
        labelss.text = t
    }
    
    func select(s: String) {
//        labelss.text = s
    }
    
    
}
