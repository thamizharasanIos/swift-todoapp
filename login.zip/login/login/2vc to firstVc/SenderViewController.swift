//
//  SenderViewController.swift
//  login
//
//  Created by thamizharasan t on 28/03/22.
//

import UIKit

protocol selectDelgate{
    func select(s: String)
    func text(t:String)
   
}

class SenderViewController: UIViewController {
    var text1: String = ""
    @IBOutlet weak var text2: UITextField!
    var selectionDelegate: selectDelgate!
    override func viewDidLoad() {
        super.viewDidLoad()
        let text1 = text2.text
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btn1(_ sender: Any) {
        selectionDelegate.select(s: text1)
        dismiss(animated: true, completion: nil)
        selectionDelegate.text(t: text2.text ?? "unknow")
    }
    
    @IBAction func btn2(_ sender: Any) {
        selectionDelegate.select(s: "two")
      
        dismiss(animated: true, completion: nil)
    }
    
    
}
