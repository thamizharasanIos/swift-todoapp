//
//  ApiViewController.swift
//  login
//
//  Created by thamizharasan t on 08/03/22.
//

import UIKit

class ApiViewController: UIViewController {

    @IBOutlet weak var emailTf: UITextField!
    @IBOutlet weak var passwordTf: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
@IBAction func SignUpBtnAction(_ sender: Any) {
            if let usertext = emailTf.text {
            let dict = AuthModel(name: usertext, is_fav: "1", user_id: "34")
            let urlStr = "https://macappstudiotraining.com/training_ios/api/createTask.php"
                        
                        if let url = URL(string: urlStr){
                            var request = URLRequest(url: url)
                            request.httpMethod = "POST"
                            let data = try? JSONEncoder.init().encode(dict)
                            request.httpBody = data
                                            URLSession.shared.dataTask(with: request) { (data, response, error) in
                                                            if let error = error{
                                                                print(error)
                                                                return
                                                            }
                                                                    if let data = data{
                                                                        do{
                                                                            let result = try JSONDecoder.init().decode(AuthResultModel.self, from: data)
                                                                            if result.status_code == 200{
                                                                                print(result.status_code)
                                                                                print(result.title)
                                                                                print(result.message)
                                                                                print("success")
//                                                                                print(result.title)
//                                                                                print(result.data.userid)
                                                                               
                                                                            }else {
                                                                                print(result.status_code)
                                                                                print(result.title)
                                                                                print(result.message)
                                                                               
                                                                                print("failed")
                                                                            }
                                                                        }catch let error{
                                                                            print(error)
                                                                        }

                                                                    }
                                                        }.resume()
                                                }else {
                                                        print("invalid URL")
                                                }
                                        }else{
                            print("email or password empty")
                            }
                }
}
struct AuthResultModel: Decodable {
    let status_code: Int
    let title: String
    let message: String
   
//    let data: ProfileModel
    
}
//struct ProfileModel: Decodable{
//    let userid: String
//}

struct AuthModel: Encodable{
    let name: String
    let is_fav: String
    let user_id: String
//    let email: String
//    let password: String
//    enum CodingKeys: String, CodingKey{
//        case  nameTf: name
//        case email = "email_id"
//        case password
//    }
}
















