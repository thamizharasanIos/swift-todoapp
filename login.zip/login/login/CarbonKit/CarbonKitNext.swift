//
//  CarbonKitNext.swift
//  login
//
//  Created by thamizharasan t on 12/04/22.
//

import UIKit

class CarbonKitNext: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    


}
