//
//  EmailValidationViewController.swift
//  login
//
//  Created by thamizharasan t on 08/03/22.
//

import UIKit

class EmailValidationViewController: UIViewController {

    @IBOutlet weak var emailTf: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    //ALERT FUNCTION FOR EMAIL
    func showAlert(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert);alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler:{(action) in alert.dismiss(animated:true, completion: nil)}))
        self.present(alert, animated: true, completion: nil)
      
    }
    //EMAIL VALIDATION FUNCTION
    func isValidEmail(testStr: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    @IBAction func EmailValidationClick(_ sender: Any) {
        let email = isValidEmail(testStr: emailTf.text!)
        if email == false {
                              showAlert(title: "ERROR", message: "This is not a valid email")
        }else{
            showAlert(title: "SUCCESS", message: "This is a valid email")
        }
    }
}
