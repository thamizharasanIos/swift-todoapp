//
//  NotificationSender2vc.swift
//  login
//
//  Created by thamizharasan t on 13/04/22.
//

import UIKit

class NotificationSender2vc: UIViewController {

    @IBOutlet weak var TextFieldOut: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    @IBAction func SaveBtn(_ sender: Any) {
        NotificationCenter.default.post(name: Notification.Name("text"), object: TextFieldOut.text)
        dismiss(animated: true, completion: nil)
    }
    
}
