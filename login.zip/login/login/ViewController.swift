//
//  ViewController.swift
//  login
//
//  Created by thamizharasan t on 24/02/22.
//

import UIKit

class ViewController: UIViewController {
    var datalist = [TaskModel]()
    

    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func AddBtnAction(_ sender: Any) {
        performSegue(withIdentifier: "addTaskvc", sender: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if let vc = segue.destination as? nextViewController {
               vc.delegte = self
           }
       }
    
}
extension ViewController: UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datalist.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid") as! vcTableViewCell
        let data = datalist[indexPath.row]
        cell.label.text = data.name
        return cell
    }
    
    
 
}
extension ViewController: datasavefunc{
    func addData(task: TaskModel) {
        datalist.append(task)
        tableView.reloadData()
    }
    
    
}
struct TaskModel {
    let name: String?
    
}
