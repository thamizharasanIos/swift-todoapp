////
////  module.swift
////  login
////
////  Created by thamizharasan t on 11/04/22.
////
//
//import Foundation
//struct AppUrl {
//  static let BaseURL = "https://macappstudiotraining.com/training_ios/stage/api/VZEANtWcva3.0/"
//
//}
//enum EndPoint: String{
//  case sendOTP = "send_OTP.php"
//
//}
//
//let baseUrl = AppUrl.BaseURL
//let endPoint = EndPoint.InsertOrganiseItemList.rawValue
//let urlStr = baseUrl + endPoint
//let usertoken = UserDefaults.standard.string(forKey: "usertoken")
//
////    let dict = InsertAuthModel(user_token: usertoken, list_token: "23573467", assets_url: "https://paintvisualizerapp.s3.ap-south-1.amazonaws.com/stage/assets/image/2.png", palettes: "44095626")
//                       if let url = URL(string: urlStr){
//                           var request = URLRequest(url: url)
//                           request.httpMethod = "POST"
//                           let data = try? JSONEncoder.init().encode(dict)
//                           request.httpBody = data
//   URLSession.shared.dataTask(with: request) { (data, response, error) in
//                   if let error = error{
//                       print(error)
//                       return
//                   }
//                   if let data = data{
//                       do{
//                           let result = try JSONDecoder.init().decode(InsertResultModel.self, from: data)
//                           if result.status_code == 200{
//                               print(result.message)
//
//                           }else {
//
//                               print(result.message)
//                           }
//                       }catch let error{
//                           print(error)
//                       }
//
//                   }
//               }.resume()
//   }else {
//           print("invalid URL")
//   }
//
//
//
//let baseUrl = AppUrl.BaseURL
//let endPoint = EndPoint.sendOTP.rawValue
//let UrlStr = baseUrl + endPoint
//
//if let url = URL(String: urlStr){
//    var result = URLRequest(url: url)
//    result.httpMethod = "POST"
//    var data = try? JSONEncoder.init().encode(dic)
//    result.httpBody = data
//    URLSession.shared.dataTask(with: result) { data, respose, error in
//        if let error = error {
//            print(error)
//            return
//        }
//        if data = data{
//            do{
//                let result = try JSONDecoder.init()Decoder(fr.self,from: data)
//                if resul.sat == 200{
//
//                }else{
//
//                }
//
//            }catch let error{
//
//            }
//        }
//    }.resume()
//}else{
//    print("invalid url")
//}
//
//
//
//
//















































