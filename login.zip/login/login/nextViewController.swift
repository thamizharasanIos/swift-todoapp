//
//  nextViewController.swift
//  login
//
//  Created by thamizharasan t on 24/02/22.
//

import UIKit
protocol datasavefunc {
    func addData(task:TaskModel)
}
class nextViewController: UIViewController {
        var delegte: datasavefunc?

    @IBOutlet weak var imgBtn: UIButton!
    @IBOutlet weak var textfield: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


    @IBAction func SaveBtnAction(_ sender: Any) {
        if let txt = textfield.text{
            let arr = TaskModel(name: txt)
            delegte?.addData(task: arr)
            navigationController?.popViewController(animated: true)
        }

    }

    @IBAction func is_FavBtn(_ sender: Any) {
        if imgBtn.tag == 0 {

            let image = UIImage(named: "favourite_ON")
            imgBtn.setImage(image, for: .normal)
            imgBtn.tag = 1
        }else {
            let image = UIImage(named: "favourite_OFF")
            imgBtn.setImage(image, for: .normal)
            imgBtn.tag = 0
        }
    }

}
