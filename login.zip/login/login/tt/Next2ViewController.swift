//
//  Next2ViewController.swift
//  login
//
//  Created by thamizharasan t on 28/03/22.
//

import UIKit

class Next2ViewController: UIViewController {

    @IBOutlet weak var lables: UILabel!
    var receivedString = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        print( receivedString)
        // Do any additional setup after loading the view.  
    }
    


}
