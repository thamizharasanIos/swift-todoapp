//
//  firstViewController.swift
//  login
//
//  Created by thamizharasan t on 28/03/22.
//

import UIKit

class firstViewController: UIViewController {

    @IBOutlet weak var text: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let secondViewController = segue.destination as! Next2ViewController
        secondViewController.receivedString = text.text!
    }

    @IBAction func goBtn(_ sender: Any) {
        performSegue(withIdentifier: "next", sender: nil)
        openLick()
    }
    
    func openLick(){
        
        if let urlToOpen = URL(string: "https://www.urbancompany.com/privacy-policy"){
            UIApplication.shared.open(urlToOpen,options: [:]){(done) in
                print("url open")
            }
        }
    }

}

